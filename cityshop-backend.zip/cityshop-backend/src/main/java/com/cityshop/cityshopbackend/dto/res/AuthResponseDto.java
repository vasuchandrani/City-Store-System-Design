package com.cityshop.cityshopbackend.dto.res;

import com.cityshop.cityshopbackend.security.role.Role;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuthResponseDto {

    private final String token;
    private final Role role;
    private final String redirectUrl;

    public AuthResponseDto(String token, Role role, String redirectUrl) {
        this.token = token;
        this.role = role;
        this.redirectUrl = redirectUrl;
    }

}


