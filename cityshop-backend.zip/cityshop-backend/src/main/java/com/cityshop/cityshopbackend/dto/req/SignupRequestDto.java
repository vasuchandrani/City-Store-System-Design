package com.cityshop.cityshopbackend.dto.req;

import com.cityshop.cityshopbackend.security.role.Role;

public interface SignupRequestDto {

    public Role getRole();
}
