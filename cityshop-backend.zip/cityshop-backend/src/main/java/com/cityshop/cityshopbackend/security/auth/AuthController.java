package com.cityshop.cityshopbackend.security.auth;

import com.cityshop.cityshopbackend.dto.req.LoginRequestDto;
import com.cityshop.cityshopbackend.dto.req.SignupRequestDto;
import com.cityshop.cityshopbackend.dto.res.AuthResponseDto;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/cityshop/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    // signup
    @PostMapping("/signup")
    public AuthResponseDto register(@RequestBody SignupRequestDto request) {
        return authService.store(request);
    }

    // login
    @PostMapping("/login")
    public AuthResponseDto login(@RequestBody LoginRequestDto request) {
        return authService.authenticate(request);
    }
}
