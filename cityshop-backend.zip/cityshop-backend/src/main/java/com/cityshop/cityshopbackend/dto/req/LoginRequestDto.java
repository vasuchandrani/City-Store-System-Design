package com.cityshop.cityshopbackend.dto.req;

import com.cityshop.cityshopbackend.security.role.Role;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginRequestDto {

    private final String email;
    private final String password;
    private final Role role;

    public LoginRequestDto(String email, String password, Role role) {
        this.email = email;
        this.password = password;
        this.role = role;
    }

}
