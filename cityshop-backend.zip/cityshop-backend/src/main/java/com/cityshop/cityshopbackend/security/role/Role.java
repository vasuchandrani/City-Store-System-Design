package com.cityshop.cityshopbackend.security.role;

public enum Role {

    CUSTOMER,
    SHOPKEEPER,
    DELIVERER;

    public String authority() {
        return "ROLE_" + this.name();
    }
}
